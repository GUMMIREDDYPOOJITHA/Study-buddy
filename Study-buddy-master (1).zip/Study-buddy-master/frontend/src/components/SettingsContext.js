import react from 'react';

const SettingsContext = react.createContext({});

export default SettingsContext;